/* 
 * File:   newfile.h
 * Author: Ruben
 *
 * Created on 5 de diciembre de 2014, 06:36 PM
 */

#ifndef NEWFILE_H
#define	NEWFILE_H

#ifdef	__cplusplus
extern "C" {
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* NEWFILE_H */

